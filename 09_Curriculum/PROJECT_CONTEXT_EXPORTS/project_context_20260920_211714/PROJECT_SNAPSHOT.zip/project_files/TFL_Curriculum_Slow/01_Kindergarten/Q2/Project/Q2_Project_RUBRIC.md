# Scoring Guide — Quarter 2 Project

> **Teacher only.**

**Target outcome:** Complete 'I remember ___ so I guess ___' with a connected pair

| Element | Points | Full credit |
|---|---|---|
| Uses material from this quarter | 5 | From this quarter, not a class example |
| Demonstrates the target outcome | 10 | Performed, not described |
| Reasoning shown | 5 | A reader can follow how they got there |
| Records made during the work | 3 | Dated; reconstruction scores 1 |
| Names what the work does not show | 2 | A specific excluded conclusion |
| **Total** | **25** | |

## Commonest shortfall

Reusing a class example. Caps row one at one point. Say so when you set it, not
when you mark it.
