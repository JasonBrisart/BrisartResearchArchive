# Printout Guide — Quarter 2

**Kindergarten** · Noticing and Remembering

Every lesson in this quarter has one matching student printout. Distribute
it **before the hook** so students can record their initial thinking before any
explanation is given.

## What is here

| Printout | Matching lesson | Pages | Distribute | Student action | After | Prior data |
|---|---|---|---|---|---|---|
| `Lesson_09_Printout.md` | Lesson 9 — Remembering Comes Back | 1–2 | Before the hook | Predicts, notes, works, concludes | Collected | None |
| `Lesson_10_Printout.md` | Lesson 10 — Two Different Jobs | 1–2 | Before the hook | Predicts, notes, works, concludes | Collected | Lesson 9 work |
| `Lesson_11_Printout.md` | Lesson 11 — Remembering Yesterday | 1–2 | Before the hook | Predicts, notes, works, concludes | Collected | Lesson 10 work |
| `Lesson_12_Printout.md` | Lesson 12 — Remembering A Song | 1–2 | Before the hook | Predicts, notes, works, concludes | Collected | Lesson 11 work |
| `Lesson_13_Printout.md` | Lesson 13 — Different Memories | 1–2 | Before the hook | Predicts, notes, works, concludes | Collected | Lesson 12 work |
| `Lesson_14_Printout.md` | Lesson 14 — Where The Guess Comes From | 1–2 | Before the hook | Predicts, notes, works, concludes | Collected | Lesson 13 work |
| `Lesson_15_Printout.md` | Lesson 15 — Same Room, Different Guesses | 1–2 | Before the hook | Predicts, notes, works, concludes | Collected | Lesson 14 work |
| `Lesson_16_Printout.md` | Lesson 16 — The Remembering Review | 1–2 | Before the hook | Predicts, notes, works, concludes | Collected | Lesson 15 work |

## When to distribute

Always before the hook. The *What I think before the lesson* section is only
meaningful if it is completed before instruction. A printout handed out after the
explanation has lost the part that makes it worth printing.

## What students complete when

| Section | When |
|---|---|
| Today's question | Before the hook |
| What I think before the lesson | Before any explanation |
| Words I need today | During the explanation |
| Follow-along notes | During the explanation |
| Worked example | With the teacher |
| Guided practice | With the teacher |
| My own work | Independently |
| Compare with a partner | In pairs |
| What my work showed | Independently |
| Exit ticket | Last five minutes, independently |

## Collection and storage

Collect at the end of each session. Return them the following session so students can see their own earlier thinking.

Portfolio: one printout per quarter, nominated by the student as their strongest
piece.

## Printing notes

- Black and white only. Nothing depends on colour.
- Single-sided is easier for students who write large.
- The response lines are sized for handwriting; do not reduce to fit fewer pages.

## Accessibility alternatives

Every written field may be completed orally with an adult scribing. Every drawn
field may be described aloud. The reasoning is what is assessed.

For students who write slowly, reduce the required number of independent examples
from three to one. One example done properly meets the outcome.

## The pivot lesson of this quarter

**Lesson 13 — Different Memories.** If you only have time to print one
printout carefully this quarter, print that one.
