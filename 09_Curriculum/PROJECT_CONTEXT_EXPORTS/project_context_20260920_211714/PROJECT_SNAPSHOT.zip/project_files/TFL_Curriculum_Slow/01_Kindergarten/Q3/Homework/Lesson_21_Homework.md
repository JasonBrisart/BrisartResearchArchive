# Lesson 21 Homework — Guessing About Tomorrow

**Kindergarten** · Noticing and Remembering · **Quarter 3**
**Follows:** Lesson 21 — Guessing About Tomorrow · **Points:** 5 · **Optional:** yes

> You are never graded on whether a prediction turned out correct. You are graded on recording it and reasoning about it. A wrong answer with reasoning scores well. A blank page scores nothing.

Name: ______________________   Date set: ________   Due: ________

---

## 1. Recall *(1 point)*

Write the sentence Lesson 21 ended on, from memory:

> "We will check tomorrow. Do not change it."

Write it from memory first, then check it against your notes and mark what you
missed.

____________________________________________________________

____________________________________________________________

## 2. The task *(2 points)*

Each child draws one tomorrow guess, kept for checking next session.

Use material nobody chose for you. Not the example worked through in class.

**Your teacher is looking for:** every child records a tomorrow guess

____________________________________________________________

____________________________________________________________

____________________________________________________________

____________________________________________________________

## 3. Explain it *(1 point)*

Explain today's lesson to **one person who was not there**.

1. Who you explained it to: ____________________________________________________________

2. The one question they asked that you could not answer:

____________________________________________________________

3. What you would need to know to answer it:

____________________________________________________________

If they asked nothing, you explained it too quickly. **The question is the graded
part, not the explanation.**

## 4. Carry forward *(1 point)*

Write today's closing sentence from memory:

____________________________________________________________

Lesson 22 is **Guessing About Each Other**, which assumes you arrive holding it. Write one thing you expect it to be about:

____________________________________________________________

---

## How this is marked

| Element | Points |
|---|---|
| Attempted and handed in | 2 |
| Written before the outcome was known, where that applies | 1 |
| Reasoning shown rather than asserted | 2 |
| **Total** | **5** |

You may revise and resubmit this once.
