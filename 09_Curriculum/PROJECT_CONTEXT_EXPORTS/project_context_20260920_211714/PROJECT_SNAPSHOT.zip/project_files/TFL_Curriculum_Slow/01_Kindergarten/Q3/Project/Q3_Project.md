# Quarter 3 Project

**Kindergarten** · Noticing and Remembering
**Built on:** Lessons 17, 18, 19, 20, 21, 22, 23, 24
**Set:** first session of the quarter · **Due:** end of the quarter · **25 points**

---

## What you are producing

Work showing you can **report a surprise and state the guess it revealed**, using material from this quarter's
sessions only.

## Steps

1. Choose your material from this quarter. Not an example worked through in class.
2. Do the work. Record what you did **as you go**, not afterwards.
3. Write what you found, with the reasoning.
4. State one thing your work does **not** show.

## Handing in

| | |
|---|---|
| **Name** | ______________________ |
| **Due** | ______________ |

## Never scored

Whether your prediction turned out correct. Whether the result was interesting.
Presentation beyond legibility.
