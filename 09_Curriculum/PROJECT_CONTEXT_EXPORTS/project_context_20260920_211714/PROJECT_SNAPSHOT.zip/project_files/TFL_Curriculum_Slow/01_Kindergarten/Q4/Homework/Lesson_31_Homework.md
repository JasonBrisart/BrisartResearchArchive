# Lesson 31 Homework — The Year Review

**Kindergarten** · Noticing and Remembering · **Quarter 4**
**Follows:** Lesson 31 — The Year Review · **Points:** 5 · **Optional:** yes

> You are never graded on whether a prediction turned out correct. You are graded on recording it and reasoning about it. A wrong answer with reasoning scores well. A blank page scores nothing.

Name: ______________________   Date set: ________   Due: ________

---

## 1. Recall *(1 point)*

Write the sentence Lesson 31 ended on, from memory:

> "Next time you show me everything."

Write it from memory first, then check it against your notes and mark what you
missed.

____________________________________________________________

____________________________________________________________

## 2. The task *(2 points)*

Children sort their own work under the four words and order it by term.

Use material nobody chose for you. Not the example worked through in class.

**Your teacher is looking for:** every child places at least six items

____________________________________________________________

____________________________________________________________

____________________________________________________________

____________________________________________________________

## 3. Explain it *(1 point)*

Explain today's lesson to **one person who was not there**.

1. Who you explained it to: ____________________________________________________________

2. The one question they asked that you could not answer:

____________________________________________________________

3. What you would need to know to answer it:

____________________________________________________________

If they asked nothing, you explained it too quickly. **The question is the graded
part, not the explanation.**

## 4. Carry forward *(1 point)*

Write today's closing sentence from memory:

____________________________________________________________

Lesson 32 is **Show What You Know**, which assumes you arrive holding it. Write one thing you expect it to be about:

____________________________________________________________

---

## How this is marked

| Element | Points |
|---|---|
| Attempted and handed in | 2 |
| Written before the outcome was known, where that applies | 1 |
| Reasoning shown rather than asserted | 2 |
| **Total** | **5** |

You may revise and resubmit this once.
