# Lesson 28 — Around Again

**Kindergarten** · Noticing and Remembering · **Quarter 4** · **20 minutes**

## Lesson at a glance

| | |
|---|---|
| **Central question** | Around Again: children show the three parts repeating? |
| **Core concept** | The three parts repeat. |
| **Student outcome** | Children show the three parts repeating. |
| **Previous lesson** | Lesson 27 — Notice, Remember, Guess |
| **Next lesson** | Lesson 29 — The Guess Jar Opens |
| **Materials** | Chart paper and markers; picture cards for sorting |
| **Preparation** | about five minutes |
| **Student printout** | `Printouts/Lesson_28_Printout.md` |
| **Homework** | `Homework/Lesson_28_Homework.md` |

## Why this lesson exists

**The conceptual step.** The three parts repeat. The second lap must start from the previous guess, which is what makes it a cycle rather than a repeat.

**Why students need it now.** This grade owns one idea: separating what is happening now from what is coming back from before.
This lesson supplies one component of it. Without this component the student can
repeat the grade's vocabulary but cannot perform the grade's outcome.

**What remains misunderstood if it is skipped.** Students will continue to believe
that noticing means anything I can think of. That belief is corrected here and nowhere else in the
quarter.

**Where it sits in the curve.** Oral and drawn. Single-word labels on drawings are allowed. Two ideas may be held together in one session and no more.

**What depends on it.** Lesson 29 — The Guess Jar Opens — opens by assuming this lesson's closing sentence is already held.

## Teacher concept guide

### Plain-language explanation

The three parts repeat. The second lap must start from the previous guess, which is what makes it a cycle rather than a repeat.

### How this is stated at this grade

Oral and drawn. Single-word labels on drawings are allowed. Two ideas may be held together in one session and no more.

Use only the vocabulary released at or before this grade. Terms not yet available:
Expect, prediction, right now, carry forward, any variable name.

### Why the concept matters

The whole grade rests on separating what is happening now from what is coming back from before. If a student leaves this
lesson without the component taught here, the remaining lessons in the quarter
will feel arbitrary, because each one assumes it.

### Two concrete examples

1. A group walks lap two starting from their lap-one guess.
2. A child explains that the end feeds the start.

### One non-example

A group that walks the same lap twice from scratch.

Use the non-example deliberately. Students who can only recognise positive cases
have learned a label rather than a distinction.

### What this activity is intended to show

That the cycle returns and continues.

### What this activity does not establish

Any formal loop property.

This distinction is not a formality. The activity is an **illustration** of an
idea, not a **test** of whether the idea is true. Say so aloud at least once.

### Scope boundary for this lesson

TFL describes short-timescale prediction, persistence, and updating. It does not
model identity, long-term memory consolidation, group behaviour, neural
implementation, or any clinical condition. If a student proposes one of those
applications, acknowledge the interest and redirect without analysing it.

### Epistemic status reminder

TFL is an original, formally specified framework. It is falsifiable in principle
and has not been independently validated. Do not present it as established. Do
not present it as unserious either — both are errors, and the second is the one
most teachers make.

### Framework doctrine versus teaching inference

| Statement | Status |
|---|---|
| The three parts repeat. | Framework-derived, appropriate at this grade |
| That the cycle returns and continues. | What this specific activity can show |
| Any formal loop property. | Explicitly outside what this activity establishes |

## What students should already know

**Prerequisite.** The content of Lesson 27 — Notice, Remember, Guess — specifically: children use all three parts on one real event.

**How it was taught.** Through the activity: every child builds a three-box trace of their own morning, with arrows

**Quick check.** Ask for the closing sentence of Lesson 27. An adequate response carries the idea in any wording.

**If the prerequisite is missing.** **Five-minute recovery.** Re-run the closing move from Lesson 27: every child builds a three-box trace of their own morning, with arrows, in miniature, using one example only. Then ask for the sentence again.

## Vocabulary and notation

### notice

| | |
|---|---|
| **Teacher definition** | what I see, hear, or feel right now. |
| **Student wording** | What i see, hear, or feel right now. |
| **Correct example** | A group walks lap two starting from their lap-one guess. |
| **Non-example** | A group that walks the same lap twice from scratch. |
| **Common misuse** | Using it for something outside this grade's release list. |
| **Correction** | "That is close. At this grade we use it only for what I see, hear, or feel right now." |

### remember

| | |
|---|---|
| **Teacher definition** | what comes back from before. |
| **Student wording** | What comes back from before. |
| **Correct example** | A group walks lap two starting from their lap-one guess. |
| **Non-example** | A group that walks the same lap twice from scratch. |
| **Common misuse** | Using it for something outside this grade's release list. |
| **Correction** | "That is close. At this grade we use it only for what comes back from before." |


Do not introduce terminology from later grades. Expect, prediction, right now, carry forward, any variable name.

## Materials and preparation

**Teacher materials.** Chart paper and markers; Picture cards for sorting; A familiar picture book; An audio source; Drawing paper.

**Student materials.** One copy of `Printouts/Lesson_28_Printout.md` per student.

**Prior student data required.** Work produced in Lesson 27, kept in the student's folder.

**If that prior work is missing.** Pair the student with somebody who has theirs
and have them use that as the reference. Do not let a missing folder stop the
lesson.

**Before students enter.** Write the central question on the board. Do not write
the closing sentence — it is produced at the end, not given at the start.

**Room setup.** Whole group for the hook, then pairs for the work step.

**Timing.** Hook 8 minutes · Explain 12 minutes ·
Work 20 minutes · Check and discussion 8 minutes ·
Close 2 minutes.

## Student printout

**File.** `Printouts/Lesson_28_Printout.md`

**Distribute.** Before the hook. Students complete the *What I think before the
lesson* section before any explanation is given.

**Completed before instruction.** Today's question, and the initial-thinking section.

**Completed with the teacher.** The vocabulary section, the worked example, and
both guided examples.

**Completed independently.** The main activity, the conclusion frames, and the
exit ticket.

**Collected.** Yes, at the end of the session.

**Portfolio.** Keep it if this is the quarter's strongest piece of the student's work.

**If a student loses it.** Reprint. Nothing in it depends on earlier pages.

**Accessibility alternative.** Every written field may be completed orally with
the teacher scribing. The reasoning is what is assessed, not the handwriting.

## Complete teaching sequence

### 1. Opening retrieval

Ask: "What did we say at the end last time?" The answer was:

> "Three things happen every time."

**Expected response.** Any wording carrying that idea.

**Likely incomplete response.** A partial version missing the second half. Accept it, then ask: "And what came after that?"

**Correction.** Supply the missing half yourself, then ask one student to say the whole sentence back.

**Decision rule.** If fewer than half the group can produce any version of it, spend five minutes on the recovery activity below before starting this lesson.

### 2. Hook

**Exact wording.** "Rebuild the chain from memory on the board, supplying nothing."

**What you physically do.** Run the hook as written. Do not explain it first and
do not tell students what they are about to notice.

**What students do.** Respond in the moment. Take several answers without
evaluating any of them.

**Likely responses.** Most students will produce the surface observation. A few
will produce the underlying one. Do not reward the second group yet.

**Time.** Five to eight minutes.

**Target observation.** That the cycle returns and continues.

**If it does not work.** If students produce nothing, run it a second time more
slowly. If it still produces nothing, move to the explanation and use the hook as
an illustration rather than a discovery. A failed hook is recoverable; a rushed
explanation is not.

**Do not reveal yet.** The closing sentence, and the conclusion the activity is
building toward.

### 3. Explain the concept

Say something close to this, in your own voice:

> "The three parts repeat. You just saw that when rebuild the chain from memory on the board, supplying nothing.
> Last time we said: Three things happen every time. This is the next part of that.
> It matters because what I notice and what I remember together make my guess"

Then state the limit explicitly:

> "This shows you what the idea means. It does not prove the idea is true. That
> would take a different kind of work than anything we do in this room."

**Terminology to introduce here.** notice, remember.

**What students must not infer.** Any formal loop property.

### 4. Worked example

**The example.** A group walks lap two starting from their lap-one guess.

**Available information.** What the student can observe directly in that case.

**Reasoning step 1.** Identify what was present before the outcome.

**Reasoning step 2.** Identify what actually happened.

**Reasoning step 3.** State the relationship between the two in the grade's
vocabulary.

**Completed answer.** A group walks lap two starting from their lap-one guess. — which demonstrates that the cycle returns and continues.

**Why it is valid.** Each step rests on something observable rather than on
something assumed.

**What would make it invalid.** Filling any step from what the student now knows
about the outcome, rather than from what was available at the time.

**Which part demonstrates the concept.** The relationship stated in step 3.

**Conclusions not licensed.** Any formal loop property.

### 5. Guided practice

#### Guided example one

**Teacher prompt.** "Here is a second case. A child explains that the end feeds the start. Work it through with me."

**Student-facing information.** The case as stated, nothing more.

**Likely response.** A correct identification with the reasoning left implicit.

**Follow-up question.** "How do you know that? Point at the part that tells you."

**Correct reasoning.** The same three steps used in the worked example.

**Common wrong answer.** Reasoning backwards from the outcome.

**Exact correction.** "You know how it ended. Cover that up and tell me what was
there before."

**Success check.** The student names the relationship without referring to the
outcome.

#### Guided example two — harder

**Teacher prompt.** "Now one that does not work. A group that walks the same lap twice from scratch. Why is this not an
example?"

**Student-facing information.** The non-example as stated.

**Likely response.** Uncertainty, or an attempt to force it into the category.

**Follow-up question.** "What would have to be different for it to count?"

**Correct reasoning.** Identify the missing element and name it.

**Common wrong answer.** Accepting it because it is superficially similar.

**Exact correction.** "It looks the same from outside. Check the one thing that
actually decides it."

**Success check.** The student names the missing element unprompted.

### 6. Independent practice

**Exact student instructions.** Floor triangle walked twice, second lap starting from the guess just made.

**Required amount.** Three completed items, unless the instruction above specifies a different number.

**Where the material comes from.** The student's own experience from today or
yesterday. Not the worked example, and not the examples used in guided practice.

**What students may use.** Their printout, their own earlier work, and a partner
for discussion.

**What students may not use.** The teacher's examples, or a classmate's completed
answer copied directly.

**What a complete response contains.** The observation, the reasoning, and the
statement of the relationship in the grade's vocabulary.

**Time.** Twenty minutes.

**Early finishers.** Ask them to find one case where the idea does **not** apply
cleanly, and to write why. Do not give them more of the same task.

**What you look for while circulating.** Students reasoning backwards from
outcomes; students reusing the worked example; students who have written a
conclusion without any supporting observation.

**What contradictory data looks like.** A case that does not fit the expected
pattern. This is a legitimate result. Record it as it stands.

**If a student cannot classify their example.** "Cannot determine" is a complete
and correct answer. Have them write it and say why.

**Do not** ask any student to change a classification so that the class result
looks tidier.

### 7. Discussion and interpretation

**Question 1.** "What did you find?"

- *Expected response.* A description of their own case.
- *Acceptable variation.* A case that did not fit.
- *Likely misconception.* Reporting the conclusion rather than the observation.
- *Correction.* "That is what you decided. What did you actually see?"
- *Licensed conclusion.* That the cycle returns and continues.
- *Not licensed.* Any formal loop property.
- *Follow-up.* "Did anybody find one that went the other way?"

**Question 2.** "Did anybody's result not fit?"

- *Expected response.* At least one student reports a case that did not fit.
- *Acceptable variation.* Nobody did, in which case say so honestly.
- *Likely misconception.* That a non-fitting result is a mistake.
- *Correction.* "That is a result, not an error. Write it down exactly as it is."
- *Licensed conclusion.* The pattern is not universal in this sample.
- *Not licensed.* That the framework is wrong, or that the student did it wrong.
- *Follow-up.* "What would we need to find out which it is?"

**Question 3.** "What does this tell us, and what does it not tell us?"

- *Expected response.* That the cycle returns and continues.
- *Acceptable variation.* Any correct restriction of the claim.
- *Likely misconception.* Overstating what one classroom activity establishes.
- *Correction.* Name the limit directly.
- *Licensed conclusion.* That the cycle returns and continues.
- *Not licensed.* Any formal loop property.
- *Follow-up.* "Who would have to do what, for us to actually know?"

**How to treat a contradictory class result.** Preserve it. Do not re-run the
activity to obtain a tidier outcome. Ask whether the method could have detected
the pattern at all, and record the answer.

### 8. Check for understanding

**Oral check 1.** "Say today's idea in one sentence."
*Criterion:* one sentence, not a list.

**Oral check 2.** "Give me an example that is not one of mine."
*Criterion:* the example is the student's own and fits.

**Oral check 3.** "Give me something this does **not** cover."
*Criterion:* any genuine exclusion.

**Written or demonstrated check.** The exit ticket below.

**Decision rule.** Continue to the next lesson only if most students pass oral
checks one and two. If they do not, spend five minutes re-running the worked
example with a new case before moving on.

### 9. Exit ticket

1. **Recall.** What was today's idea, in one sentence?
2. **Application.** Give one example of your own.
3. **Misconception check.** Somebody says: "Noticing means anything I can think of" What would you tell them?

## Teacher-only exit-ticket key

> **Teacher only.** This does not appear on the student printout.

1. Any wording carrying the idea in `The three parts repeat`.
2. Any case that fits and is not one of the teacher's examples. A reused teacher
   example scores partial credit only.
3. Any correction carrying the sense of: That is remembering. What do you notice right now, with your ears?

**Not scored:** whether any prediction the student describes turned out correct.

### 10. Carry forward

Say: "It does not stop when you leave."

**Why this sentence matters.** It is the opening question of Lesson 29, which assumes students arrive holding it.

**Open the next lesson with.** "What did we say at the end last time?"

## Expected student work

**Strong response.** Gives the observation, the reasoning, and the relationship,
using the grade's vocabulary, with an example the student generated themselves.

**Developing response.** Gives the observation and the conclusion but omits the
reasoning connecting them.

**Why it is incomplete.** Without the middle step there is no way to tell whether
the student reasoned or guessed.

**Corrected version.** The same response with one added sentence beginning "I
know this because" followed by the observation it rests on.



## Misconceptions and corrections

### 1. "Noticing means anything I can think of"

**What the student says or does.** Noticing means anything I can think of — usually while otherwise engaging well.

**Why it is understandable.** Notice is not yet distinct from think about.

**How you detect it.** Listen for it during the work step and the discussion. It
surfaces most often when a student explains their reasoning aloud.

**Exact correction.** Redirect to the senses and the present moment.

**Say this.** "That is remembering. What do you notice right now, with your ears?"

**Follow-up that confirms the correction worked.** Ask the student to give a
second example of their own, unprompted. If the second example repeats the
misconception, reteach rather than moving on.

### 2. "Remembering means trying hard to remember"

**What the student says or does.** Remembering means trying hard to remember — usually while otherwise engaging well.

**Why it is understandable.** Elsewhere memory is taught as deliberate recall.

**How you detect it.** Listen for it during the work step and the discussion. It
surfaces most often when a student explains their reasoning aloud.

**Exact correction.** Say 'ready, set' and let them shout GO. Nobody tried.

**Say this.** "It came back on its own. That is remembering here."

**Follow-up that confirms the correction worked.** Ask the student to give a
second example of their own, unprompted. If the second example repeats the
misconception, reteach rather than moving on.

### 3. "If nothing surprised me, I did not guess"

**What the student says or does.** If nothing surprised me, I did not guess — usually while otherwise engaging well.

**Why it is understandable.** Surprise is the only visible evidence.

**How you detect it.** Listen for it during the work step and the discussion. It
surfaces most often when a student explains their reasoning aloud.

**Exact correction.** Ask what would happen if their chair broke. They react.

**Say this.** "When your guess is right you do not notice it at all."

**Follow-up that confirms the correction worked.** Ask the student to give a
second example of their own, unprompted. If the second example repeats the
misconception, reteach rather than moving on.

### 4. "This lesson proves the framework is right"

**What the student says or does.** Treats the classroom result as evidence that
TFL is correct.

**Why it is understandable.** The activity was designed to make the idea visible,
so it looks like a demonstration of truth.

**How you detect it.** Listen for "so this proves" or "this shows TFL is right."

**Exact correction.** Separate illustration from validation explicitly.

**Say this.** "This showed you what the idea means. It did not test whether the
idea is true. Nobody in this room has tested that."

**Follow-up.** Ask what would have to happen for somebody to actually test it.
Any honest answer is acceptable; the point is that the student sees the gap.


## Support without lowering the concept

**Oral support.** Let the student answer aloud while you scribe. The concept is
unchanged; only the output channel moves.

**Visual or physical support.** Do everything orally in pairs before asking for a drawing.

**Reduced output.** One complete example rather than three. A student who can do
one properly has met the outcome.

**Sentence frame.** "I saw ______. That means ______, because ______."

**Recovery task.** Re-run the worked example with a new case, one step at a time,
with the student supplying each step.

**Accessibility alternative.** Every written field may be spoken. Every drawn
field may be described.

## Extension

Ask the child to notice one thing they usually never notice.

Do not use extension to release next grade's vocabulary. A student working ahead
should go **deeper into this grade's idea**, not sideways into the next one.
Specifically, do not introduce: Expect, prediction, right now, carry forward, any variable name.

## Scope and safety notes

- Prediction accuracy is never graded. You are never graded on whether a prediction turned out correct. You are graded on recording it and reasoning about it.
- Do not use this framework to interpret, describe, or diagnose any student.
- Do not solicit personal distress. Use games, weather, schedules, and routine
  events as the source of examples.
- Do not attribute agency, intention, or wanting to the system being described.
- Do not claim this activity proves the framework. It illustrates an idea.
- Do not describe class data as independent validation. It is not.
- Do not infer neural mechanisms. The framework specifies none.


## Homework connection

**File.** `Homework/Lesson_28_Homework.md`

**What it reinforces.** The same outcome, performed once outside the room on
material nobody selected for the student.

**Prerequisite it assumes.** Today's closing sentence and one worked example.

**How to set it.** Optional. Set it if this is the pivot lesson of the quarter,
if today released new vocabulary, or if an assessment is coming.

**What to look for when marking.** Reasoning shown, and the closing sentence
reproduced from memory. Not accuracy of any prediction described.

**Which errors trigger reteaching.** A homework that reuses a teacher example, or
that reasons backwards from the outcome, indicates the concept has not landed.

**Printout needed.** No. The homework stands alone.

**Portfolio.** Only if the student nominates it as their strongest work this
quarter.

## Teacher reflection after the lesson

1. Which part of the concept did students understand?
2. Which misconception was still present at the end?
3. Did the hook produce the intended observation?
4. What evidence supports that judgement — what did you actually see or hear?
5. Did any contradictory result appear?
6. Was it preserved honestly, or quietly dropped?
7. What must be retaught before the next lesson?
8. Is the next lesson still appropriate, or does it need a bridging activity?

## Sequence

| | |
|---|---|
| **Follows** | Lesson 27 — Notice, Remember, Guess |
| **Leads to** | Lesson 29 — The Guess Jar Opens |

**Transition in.** Lesson 27 established children use all three parts on one real event. This lesson uses that as the starting point.

**Transition out.** This lesson establishes children show the three parts repeating. Lesson 29 assumes it and builds children check the long-interval guess from Lesson 19.
