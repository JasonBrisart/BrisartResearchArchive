# Printout Guide — Quarter 4

**Pre-Kindergarten** · Guessing Games

Every lesson in this quarter has one matching student printout. Distribute
it **before the hook** so students can record their initial thinking before any
explanation is given.

## What is here

| Printout | Matching lesson | Pages | Distribute | Student action | After | Prior data |
|---|---|---|---|---|---|---|
| `Lesson_25_Printout.md` | Lesson 25 — Guess Again | 1 | Before the hook | Draws and speaks | Stays with family | None |
| `Lesson_26_Printout.md` | Lesson 26 — What Happened, Then What | 1 | Before the hook | Draws and speaks | Stays with family | Lesson 25 work |
| `Lesson_27_Printout.md` | Lesson 27 — Walking The Circle | 1 | Before the hook | Draws and speaks | Stays with family | Lesson 26 work |
| `Lesson_28_Printout.md` | Lesson 28 — Drawing The Circle | 1 | Before the hook | Draws and speaks | Stays with family | Lesson 27 work |
| `Lesson_29_Printout.md` | Lesson 29 — The Circle At Home | 1 | Before the hook | Draws and speaks | Stays with family | Lesson 28 work |
| `Lesson_30_Printout.md` | Lesson 30 — Teaching A Grown-Up | 1 | Before the hook | Draws and speaks | Stays with family | Lesson 29 work |
| `Lesson_31_Printout.md` | Lesson 31 — The Year In Pictures | 1 | Before the hook | Draws and speaks | Stays with family | Lesson 30 work |
| `Lesson_32_Printout.md` | Lesson 32 — Show What You Know | 1 | Before the hook | Draws and speaks | Stays with family | Lesson 31 work |

## When to distribute

Always before the hook. The *What I think before the lesson* section is only
meaningful if it is completed before instruction. A printout handed out after the
explanation has lost the part that makes it worth printing.

## What students complete when

| Section | When |
|---|---|
| Today's question | Before the hook |
| What I think before the lesson | Before any explanation |
| Words I need today | During the explanation |
| Follow-along notes | During the explanation |
| Worked example | With the teacher |
| Guided practice | With the teacher |
| My own work | Independently |
| Compare with a partner | In pairs |
| What my work showed | Independently |
| Exit ticket | Last five minutes, independently |

## Collection and storage

These sheets stay with the family. Keep a teacher record of what each child said and drew.

Portfolio: one printout per quarter, nominated by the student as their strongest
piece.

## Printing notes

- Black and white only. Nothing depends on colour.
- Single-sided is easier for students who write large.
- The response lines are sized for handwriting; do not reduce to fit fewer pages.

## Accessibility alternatives

Every written field may be completed orally with an adult scribing. Every drawn
field may be described aloud. The reasoning is what is assessed.

For students who write slowly, reduce the required number of independent examples
from three to one. One example done properly meets the outcome.

## The pivot lesson of this quarter

**Lesson 29 — The Circle At Home.** If you only have time to print one
printout carefully this quarter, print that one.
