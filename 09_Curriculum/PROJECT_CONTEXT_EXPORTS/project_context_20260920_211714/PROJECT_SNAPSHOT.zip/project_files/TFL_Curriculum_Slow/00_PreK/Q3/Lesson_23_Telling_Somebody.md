# Lesson 23 — Telling Somebody

**Pre-Kindergarten** · Guessing Games · **Quarter 3** · **15 minutes**

## Lesson at a glance

| | |
|---|---|
| **Central question** | Telling Somebody: children explain sticking to another person? |
| **Core concept** | Explaining to somebody who was absent is the strongest available check at this age, because the child cannot rely on shared context. |
| **Student outcome** | Children explain sticking to another person. |
| **Previous lesson** | Lesson 22 — The Sticking Sort |
| **Next lesson** | Lesson 24 — The Sticking Review |
| **Materials** | A cloth or bag to hide objects; familiar picture books |
| **Preparation** | about two minutes |
| **Student printout** | `Printouts/Lesson_23_Printout.md` |
| **Homework** | `Homework/Lesson_23_Homework.md` |

## Why this lesson exists

**The conceptual step.** Explaining to somebody who was absent is the strongest available check at this age, because the child cannot rely on shared context.

**Why students need it now.** This grade owns one idea: that a guess exists at all, and that surprise is what a wrong guess feels like.
This lesson supplies one component of it. Without this component the student can
repeat the grade's vocabulary but cannot perform the grade's outcome.

**What remains misunderstood if it is skipped.** Students will continue to believe
that guessing means saying something silly. That belief is corrected here and nowhere else in the
quarter.

**Where it sits in the curve.** Entirely oral and physical. No reading, no writing, no counting. A child answers by speaking, pointing, moving, or drawing. One idea per session.

**What depends on it.** Lesson 24 — The Sticking Review — opens by assuming this lesson's closing sentence is already held.

## Teacher concept guide

### Plain-language explanation

Explaining to somebody who was absent is the strongest available check at this age, because the child cannot rely on shared context.

### How this is stated at this grade

Entirely oral and physical. No reading, no writing, no counting. A child answers by speaking, pointing, moving, or drawing. One idea per session.

Use only the vocabulary released at or before this grade. Terms not yet available:
Notice, remember, expect, prediction, memory, brain, emotion. None of these yet.

### Why the concept matters

The whole grade rests on that a guess exists at all, and that surprise is what a wrong guess feels like. If a student leaves this
lesson without the component taught here, the remaining lessons in the quarter
will feel arbitrary, because each one assumes it.

### Two concrete examples

1. A child tells a visitor that the song stuck.
2. A child explains that a right guess went away.

### One non-example

A child who repeats the teacher's words with no example attached.

Use the non-example deliberately. Students who can only recognise positive cases
have learned a label rather than a distinction.

### What this activity is intended to show

Whether the child can produce the idea unsupported.

### What this activity does not establish

Whether the explanation is complete or accurate.

This distinction is not a formality. The activity is an **illustration** of an
idea, not a **test** of whether the idea is true. Say so aloud at least once.

### Scope boundary for this lesson

TFL describes short-timescale prediction, persistence, and updating. It does not
model identity, long-term memory consolidation, group behaviour, neural
implementation, or any clinical condition. If a student proposes one of those
applications, acknowledge the interest and redirect without analysing it.

### Epistemic status reminder

TFL is an original, formally specified framework. It is falsifiable in principle
and has not been independently validated. Do not present it as established. Do
not present it as unserious either — both are errors, and the second is the one
most teachers make.

### Framework doctrine versus teaching inference

| Statement | Status |
|---|---|
| Explaining to somebody who was absent is the strongest available check at this age, because the child cannot rely on shared context. | Framework-derived, appropriate at this grade |
| Whether the child can produce the idea unsupported. | What this specific activity can show |
| Whether the explanation is complete or accurate. | Explicitly outside what this activity establishes |

## What students should already know

**Prerequisite.** The content of Lesson 22 — The Sticking Sort — specifically: children sort guesses by whether they stuck.

**How it was taught.** Through the activity: children physically place drawings of their guesses into the two hoops

**Quick check.** Ask for the closing sentence of Lesson 22. An adequate response carries the idea in any wording.

**If the prerequisite is missing.** **Five-minute recovery.** Re-run the closing move from Lesson 22: children physically place drawings of their guesses into the two hoops, in miniature, using one example only. Then ask for the sentence again.

## Vocabulary and notation

### guess

| | |
|---|---|
| **Teacher definition** | saying what you think happens next. |
| **Student wording** | Saying what you think happens next. |
| **Correct example** | A child tells a visitor that the song stuck. |
| **Non-example** | A child who repeats the teacher's words with no example attached. |
| **Common misuse** | Using it for something outside this grade's release list. |
| **Correction** | "That is close. At this grade we use it only for saying what you think happens next." |

### surprise

| | |
|---|---|
| **Teacher definition** | when something different happened than you guessed. |
| **Student wording** | When something different happened than you guessed. |
| **Correct example** | A child tells a visitor that the song stuck. |
| **Non-example** | A child who repeats the teacher's words with no example attached. |
| **Common misuse** | Using it for something outside this grade's release list. |
| **Correction** | "That is close. At this grade we use it only for when something different happened than you guessed." |

### again

| | |
|---|---|
| **Teacher definition** | it happens over and over and does not stop. |
| **Student wording** | It happens over and over and does not stop. |
| **Correct example** | A child tells a visitor that the song stuck. |
| **Non-example** | A child who repeats the teacher's words with no example attached. |
| **Common misuse** | Using it for something outside this grade's release list. |
| **Correction** | "That is close. At this grade we use it only for it happens over and over and does not stop." |


Do not introduce terminology from later grades. Notice, remember, expect, prediction, memory, brain, emotion. None of these yet.

## Materials and preparation

**Teacher materials.** A cloth or bag to hide objects; Familiar picture books; A noisemaker or audio source; Drawing paper and crayons; One small object to pass around.

**Student materials.** One copy of `Printouts/Lesson_23_Printout.md` per student.

**Prior student data required.** Work produced in Lesson 22, kept in the student's folder.

**If that prior work is missing.** Pair the student with somebody who has theirs
and have them use that as the reference. Do not let a missing folder stop the
lesson.

**Before students enter.** Write the central question on the board. Do not write
the closing sentence — it is produced at the end, not given at the start.

**Room setup.** Circle or carpet space for the whole session.

**Timing.** Hook 3 minutes · Explain 3 minutes ·
Work 6 minutes · Check and discussion 2 minutes ·
Close 2 minutes.

## Student printout

**File.** `Printouts/Lesson_23_Printout.md`

**Distribute.** Before the hook. Students complete the *What I think before the
lesson* section before any explanation is given.

**Completed before instruction.** Today's question, and the initial-thinking section.

**Completed with the teacher.** The vocabulary section, the worked example, and
both guided examples.

**Completed independently.** The main activity, the conclusion frames, and the
exit ticket.

**Collected.** No — this is an adult-led sheet and stays with the family.

**Portfolio.** Teacher keeps a sample for the observation record.

**If a student loses it.** Reprint. Nothing in it depends on earlier pages.

**Accessibility alternative.** Every written field may be completed orally with
the teacher scribing. The reasoning is what is assessed, not the handwriting.

## Complete teaching sequence

### 1. Opening retrieval

Ask: "What did we say at the end last time?" The answer was:

> "Look how many are in each. It is not about being right."

**Expected response.** Any wording carrying that idea.

**Likely incomplete response.** A partial version missing the second half. Accept it, then ask: "And what came after that?"

**Correction.** Supply the missing half yourself, then ask one student to say the whole sentence back.

**Decision rule.** If fewer than half the group can produce any version of it, spend five minutes on the recovery activity below before starting this lesson.

### 2. Hook

**Exact wording.** "Tell them they will explain this to somebody who was not here."

**What you physically do.** Run the hook as written. Do not explain it first and
do not tell students what they are about to notice.

**What students do.** Respond in the moment. Take several answers without
evaluating any of them.

**Likely responses.** Most students will produce the surface observation. A few
will produce the underlying one. Do not reward the second group yet.

**Time.** Two to three minutes.

**Target observation.** Whether the child can produce the idea unsupported.

**If it does not work.** If students produce nothing, run it a second time more
slowly. If it still produces nothing, move to the explanation and use the hook as
an illustration rather than a discovery. A failed hook is recoverable; a rushed
explanation is not.

**Do not reveal yet.** The closing sentence, and the conclusion the activity is
building toward.

### 3. Explain the concept

Say something close to this, in your own voice:

> "Explaining to somebody who was absent is the strongest available check at this age, because the child cannot rely on shared context. You just saw that when tell them they will explain this to somebody who was not here.
> Last time we said: Look how many are in each. It is not about being right. This is the next part of that.
> It matters because your brain is already guessing what happens next"

Then state the limit explicitly:

> "This shows you what the idea means. It does not prove the idea is true. That
> would take a different kind of work than anything we do in this room."

**Terminology to introduce here.** guess, surprise, again.

**What students must not infer.** Whether the explanation is complete or accurate.

### 4. Worked example

**The example.** A child tells a visitor that the song stuck.

**Available information.** What the student can observe directly in that case.

**Reasoning step 1.** Identify what was present before the outcome.

**Reasoning step 2.** Identify what actually happened.

**Reasoning step 3.** State the relationship between the two in the grade's
vocabulary.

**Completed answer.** A child tells a visitor that the song stuck. — which demonstrates whether the child can produce the idea unsupported.

**Why it is valid.** Each step rests on something observable rather than on
something assumed.

**What would make it invalid.** Filling any step from what the student now knows
about the outcome, rather than from what was available at the time.

**Which part demonstrates the concept.** The relationship stated in step 3.

**Conclusions not licensed.** Whether the explanation is complete or accurate.

### 5. Guided practice

#### Guided example one

**Teacher prompt.** "Here is a second case. A child explains that a right guess went away. Work it through with me."

**Student-facing information.** The case as stated, nothing more.

**Likely response.** A correct identification with the reasoning left implicit.

**Follow-up question.** "How do you know that? Point at the part that tells you."

**Correct reasoning.** The same three steps used in the worked example.

**Common wrong answer.** Reasoning backwards from the outcome.

**Exact correction.** "You know how it ended. Cover that up and tell me what was
there before."

**Success check.** The student names the relationship without referring to the
outcome.

#### Guided example two — harder

**Teacher prompt.** "Now one that does not work. A child who repeats the teacher's words with no example attached. Why is this not an
example?"

**Student-facing information.** The non-example as stated.

**Likely response.** Uncertainty, or an attempt to force it into the category.

**Follow-up question.** "What would have to be different for it to count?"

**Correct reasoning.** Identify the missing element and name it.

**Common wrong answer.** Accepting it because it is superficially similar.

**Exact correction.** "It looks the same from outside. Check the one thing that
actually decides it."

**Success check.** The student names the missing element unprompted.

### 6. Independent practice

**Exact student instructions.** Pair with an older buddy class or a visiting adult. Each child explains stuck versus gone.

**Required amount.** One completed item, spoken or drawn.

**Where the material comes from.** The student's own experience from today or
yesterday. Not the worked example, and not the examples used in guided practice.

**What students may use.** Their printout, their own earlier work, and a partner
for discussion.

**What students may not use.** The teacher's examples, or a classmate's completed
answer copied directly.

**What a complete response contains.** The observation, the reasoning, and the
statement of the relationship in the grade's vocabulary.

**Time.** Six minutes.

**Early finishers.** Ask them to find one case where the idea does **not** apply
cleanly, and to write why. Do not give them more of the same task.

**What you look for while circulating.** Students reasoning backwards from
outcomes; students reusing the worked example; students who have written a
conclusion without any supporting observation.

**What contradictory data looks like.** A case that does not fit the expected
pattern. This is a legitimate result. Record it as it stands.

**If a student cannot classify their example.** "Cannot determine" is a complete
and correct answer. Have them write it and say why.

**Do not** ask any student to change a classification so that the class result
looks tidier.

### 7. Discussion and interpretation

**Question 1.** "What did you find?"

- *Expected response.* A description of their own case.
- *Acceptable variation.* A case that did not fit.
- *Likely misconception.* Reporting the conclusion rather than the observation.
- *Correction.* "That is what you decided. What did you actually see?"
- *Licensed conclusion.* Whether the child can produce the idea unsupported.
- *Not licensed.* Whether the explanation is complete or accurate.
- *Follow-up.* "Did anybody find one that went the other way?"

**Question 2.** "Did anybody's result not fit?"

- *Expected response.* At least one student reports a case that did not fit.
- *Acceptable variation.* Nobody did, in which case say so honestly.
- *Likely misconception.* That a non-fitting result is a mistake.
- *Correction.* "That is a result, not an error. Write it down exactly as it is."
- *Licensed conclusion.* The pattern is not universal in this sample.
- *Not licensed.* That the framework is wrong, or that the student did it wrong.
- *Follow-up.* "What would we need to find out which it is?"

**Question 3.** "What does this tell us, and what does it not tell us?"

- *Expected response.* Whether the child can produce the idea unsupported.
- *Acceptable variation.* Any correct restriction of the claim.
- *Likely misconception.* Overstating what one classroom activity establishes.
- *Correction.* Name the limit directly.
- *Licensed conclusion.* Whether the child can produce the idea unsupported.
- *Not licensed.* Whether the explanation is complete or accurate.
- *Follow-up.* "Who would have to do what, for us to actually know?"

**How to treat a contradictory class result.** Preserve it. Do not re-run the
activity to obtain a tidier outcome. Ask whether the method could have detected
the pattern at all, and record the answer.

### 8. Check for understanding

**Oral check 1.** "Say today's idea in one sentence."
*Criterion:* one sentence, not a list.

**Oral check 2.** "Give me an example that is not one of mine."
*Criterion:* the example is the student's own and fits.

**Oral check 3.** "Give me something this does **not** cover."
*Criterion:* any genuine exclusion.

**Written or demonstrated check.** The exit ticket below.

**Decision rule.** Continue to the next lesson only if most students pass oral
checks one and two. If they do not, spend five minutes re-running the worked
example with a new case before moving on.

### 9. Exit ticket

1. **Recall.** Say back today's word.
2. **Application.** Give one example of your own.
3. **Misconception check.** Somebody says: "Guessing means saying something silly" What would you tell them?

## Teacher-only exit-ticket key

> **Teacher only.** This does not appear on the student printout.

1. Any wording carrying the idea in `Explaining to somebody who was absent is the strongest available check at this age, because the child cannot rely on shared context`.
2. Any case that fits and is not one of the teacher's examples. A reused teacher
   example scores partial credit only.
3. Any correction carrying the sense of: See? That was a guess too. A good one.

**Not scored:** whether any prediction the student describes turned out correct.

### 10. Carry forward

Say: "If you can say it to somebody else, you know it."

**Why this sentence matters.** It is the opening question of Lesson 24, which assumes students arrive holding it.

**Open the next lesson with.** "What did we say at the end last time?"

## Expected student work

**Strong response.** Gives the observation, the reasoning, and the relationship,
using the grade's vocabulary, with an example the student generated themselves.

**Developing response.** Gives the observation and the conclusion but omits the
reasoning connecting them.

**Why it is incomplete.** Without the middle step there is no way to tell whether
the student reasoned or guessed.

**Corrected version.** The same response with one added sentence beginning "I
know this because" followed by the observation it rests on.

**At this grade** student work is spoken, drawn, or physically demonstrated rather than written. Record what the child says.

## Misconceptions and corrections

### 1. "Guessing means saying something silly"

**What the student says or does.** Guessing means saying something silly — usually while otherwise engaging well.

**Why it is understandable.** Nobody has told them a guess is real, so they treat it as a joke answer.

**How you detect it.** Listen for it during the work step and the discussion. It
surfaces most often when a student explains their reasoning aloud.

**Exact correction.** Ask about something they will certainly get right. 'What happens if I let go of this?'

**Say this.** "See? That was a guess too. A good one."

**Follow-up that confirms the correction worked.** Ask the student to give a
second example of their own, unprompted. If the second example repeats the
misconception, reteach rather than moving on.

### 2. "Being wrong means I did something bad"

**What the student says or does.** Being wrong means I did something bad — usually while otherwise engaging well.

**Why it is understandable.** At this age a wrong answer reads as a rule broken.

**How you detect it.** Listen for it during the work step and the discussion. It
surfaces most often when a student explains their reasoning aloud.

**Exact correction.** Model it. Guess aloud, be wrong on purpose, be delighted.

**Say this.** "I was wrong! That is my favourite part."

**Follow-up that confirms the correction worked.** Ask the student to give a
second example of their own, unprompted. If the second example repeats the
misconception, reteach rather than moving on.

### 3. "I only guess when you ask me to"

**What the student says or does.** I only guess when you ask me to — usually while otherwise engaging well.

**Why it is understandable.** A correct guess is invisible, so guessing feels like it happens on request.

**How you detect it.** Listen for it during the work step and the discussion. It
surfaces most often when a student explains their reasoning aloud.

**Exact correction.** Stop mid-activity and ask what is behind them. They answer without looking.

**Say this.** "Nobody looked. Everybody knew. It was already in there."

**Follow-up that confirms the correction worked.** Ask the student to give a
second example of their own, unprompted. If the second example repeats the
misconception, reteach rather than moving on.

### 4. "This lesson proves the framework is right"

**What the student says or does.** Treats the classroom result as evidence that
TFL is correct.

**Why it is understandable.** The activity was designed to make the idea visible,
so it looks like a demonstration of truth.

**How you detect it.** Listen for "so this proves" or "this shows TFL is right."

**Exact correction.** Separate illustration from validation explicitly.

**Say this.** "This showed you what the idea means. It did not test whether the
idea is true. Nobody in this room has tested that."

**Follow-up.** Ask what would have to happen for somebody to actually test it.
Any honest answer is acceptable; the point is that the student sees the gap.


## Support without lowering the concept

**Oral support.** Let the student answer aloud while you scribe. The concept is
unchanged; only the output channel moves.

**Visual or physical support.** Offer a choice of two rather than an open question.

**Reduced output.** One complete example rather than three. A student who can do
one properly has met the outcome.

**Sentence frame.** "I saw ______. That means ______, because ______."

**Recovery task.** Re-run the worked example with a new case, one step at a time,
with the student supplying each step.

**Accessibility alternative.** Every written field may be spoken. Every drawn
field may be described.

## Extension

Ask the child to set up the guessing game for a partner.

Do not use extension to release next grade's vocabulary. A student working ahead
should go **deeper into this grade's idea**, not sideways into the next one.
Specifically, do not introduce: Notice, remember, expect, prediction, memory, brain, emotion. None of these yet.

## Scope and safety notes

- Prediction accuracy is never graded. You are never graded on whether a prediction turned out correct. You are graded on recording it and reasoning about it.
- Do not use this framework to interpret, describe, or diagnose any student.
- Do not solicit personal distress. Use games, weather, schedules, and routine
  events as the source of examples.
- Do not attribute agency, intention, or wanting to the system being described.
- Do not claim this activity proves the framework. It illustrates an idea.
- Do not describe class data as independent validation. It is not.
- Do not infer neural mechanisms. The framework specifies none.


## Homework connection

**File.** `Homework/Lesson_23_Homework.md`

**What it reinforces.** The same outcome, performed once outside the room on
material nobody selected for the student.

**Prerequisite it assumes.** Today's closing sentence and one worked example.

**How to set it.** Optional. Set it if this is the pivot lesson of the quarter,
if today released new vocabulary, or if an assessment is coming.

**What to look for when marking.** Reasoning shown, and the closing sentence
reproduced from memory. Not accuracy of any prediction described.

**Which errors trigger reteaching.** A homework that reuses a teacher example, or
that reasons backwards from the outcome, indicates the concept has not landed.

**Printout needed.** No. The homework stands alone.

**Portfolio.** Only if the student nominates it as their strongest work this
quarter.

## Teacher reflection after the lesson

1. Which part of the concept did students understand?
2. Which misconception was still present at the end?
3. Did the hook produce the intended observation?
4. What evidence supports that judgement — what did you actually see or hear?
5. Did any contradictory result appear?
6. Was it preserved honestly, or quietly dropped?
7. What must be retaught before the next lesson?
8. Is the next lesson still appropriate, or does it need a bridging activity?

## Sequence

| | |
|---|---|
| **Follows** | Lesson 22 — The Sticking Sort |
| **Leads to** | Lesson 24 — The Sticking Review |

**Transition in.** Lesson 22 established children sort guesses by whether they stuck. This lesson uses that as the starting point.

**Transition out.** This lesson establishes children explain sticking to another person. Lesson 24 assumes it and builds children consolidate the quarter's sticking work.
